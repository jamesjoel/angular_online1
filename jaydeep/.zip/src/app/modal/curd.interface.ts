export interface Curd{
    id? : number;
    fullname : string;
    lastname : string;
    email : string;
    password: string;
    mobile : string;
    city : string;
    gender : string
}